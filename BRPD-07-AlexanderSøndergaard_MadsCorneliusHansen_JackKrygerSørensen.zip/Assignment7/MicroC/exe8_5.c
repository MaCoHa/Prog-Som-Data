﻿void main(int n)
{
    int r;
    r = n ? 1 : 0;
    print r;
    println;
}